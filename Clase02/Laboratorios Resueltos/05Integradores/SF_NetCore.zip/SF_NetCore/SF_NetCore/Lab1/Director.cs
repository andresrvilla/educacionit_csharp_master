﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SF_NetCore
{
    public class Director: Profesor
    {
        public int NroInstituto { get; set; }
    }
}
