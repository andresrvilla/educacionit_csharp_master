﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SF
{
    public class Banco
    {
        private Cliente cliente1, cliente2, cliente3;
        public Banco()
        {
            cliente1 = new Cliente("Cesar");
            cliente2 = new Cliente("Ana");
            cliente3 = new Cliente("Pedro");
        }
        public void Operar()
        {
            cliente1.Depositar(100);
            cliente2.Depositar(150);
            cliente3.Depositar(200);
            cliente3.Extraer(150);
        }
        public string DepositosTotales()
        {
            //Nota: Esta logica de negocios esta mal creada puesto a que esta infiriendo codigo dentro de las clases. Lo cual
            //No es correcto desde el punto de vista de las aplicaciones en Capas. No obstante se presenta un ejemplo simple
            //para que pueda reconocer la firma y los valores devueltos. Tenga en cuenta que veremos durante el curso la manera
            //correcta
            int t = cliente1.RetornarMonto() +
                    cliente2.RetornarMonto() +
                    cliente3.RetornarMonto();
            var dato = "El total de dinero en el banco es: $" + t + ".- " + "\r" + "\n";
            dato = dato + " " + cliente1.Imprimir();
            dato = dato + " " + cliente2.Imprimir();
            dato = dato + " " + cliente3.Imprimir();

            return dato;
        }
    }
}
