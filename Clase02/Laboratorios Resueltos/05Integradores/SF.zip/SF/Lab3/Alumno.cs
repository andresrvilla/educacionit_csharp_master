﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SF.Lab3
{
    public class Alumno
    {
        private string nombre;
        private int edad;
        public Alumno(string pNombre, string pEdad)
        {
            nombre = pNombre;
            edad = int.Parse(pEdad);
        }
        public string Imprimir()
        {
            return "Nombre:" + nombre + " Edad: " + edad.ToString();
        }
        public string EsMayorEdad()
        {
            if (edad >= 18)
            {
                return nombre + " es mayor de edad.";
            }
            else
            {
                return nombre + " no es mayor de edad.";
            }
        }
    
    }
}

